package StaticArrays;

public class learnjava {

	boolean learn = true;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// classname object=new classname();

		learnjava emp = new learnjava();

		if (emp.learn) {
			System.out.println("Are you willing to Learn Selenium");
		} else {
			System.out.println("Are you willing to Learn Java");

		}

	}

}
